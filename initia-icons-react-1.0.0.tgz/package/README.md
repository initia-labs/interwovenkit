# @initia/icons-react
## Usage

```js
import { IconName } from "@initia/icons-react"

<IconName color="white" size={50}/>
```
> You can find a list with all the available icons [here](https://initia-icons.vercel.app/)

Both props (color and size) are oprional, these are the default values:

Prop          | Default value
------------- | -------------
color         | "currentColor"
size          | 16